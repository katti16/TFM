library(ggplot2)
library(tidyr)
library(readxl)
setwd('C:/Users/katti/Desktop/Máster/TFM/HLW_2023_Replication_Code - TFM/output')

# READ RESULTS DATA
df <- read_excel("ea_results.xlsx")
df2 <- read_excel("us_results.xlsx")
df3 <- read_excel("us_robustness1_results.xlsx")

names(df)[1] <- "Date"
names(df2)[1] <- "Date"
df <- df[,1:8]
df2 <- df2[,1:8]
df[, 2:3] <- lapply(df[, 2:3], as.numeric)
df <- df[,1:4]
df2 <- df2[,1:4]

#Load EA estimates
ea_hlw_r <- ts(df$rstar_hlw, start = c(1972, 1), frequency = 4)  
ea_hlw_r_cy <- ts(df$rstar_trend_cy, start = c(1972, 1), frequency = 4)  
ea_hlw_z <- ts(df$z_hlw, start = c(1972, 1), frequency = 4)  
ea_hlw_z_cy <- ts(df$z_trend_cy, start = c(1972, 1), frequency = 4)  
ea_hlw_g <- ts(df$g_hlw, start = c(1972, 1), frequency = 4)  
ea_hlw_g_cy <- ts(df$g_trend_cy, start = c(1972, 1), frequency = 4)  

#TS PLOT: comparing EA original HLW estimates and our own.
plot(ea_hlw_r_cy, type = "l", col = "lightblue4",
      xlab = "Date", ylab = "Rate",lwd=2,ylim=c(-1.5,1)) 
lines(ea_hlw_r,col="red4",lwd=2)

legend("topright",
       legend = c("HLW r*","HLW r* including trend cy"),
       col = c("red4","lightblue4"),
       lty = c(1, 1),
       lwd = c(2, 2),
       bty = "n")

#Load US estimates
us_hlw_r <- ts(df2$rstar_hlw, start = c(1961, 1), frequency = 4)  
us_hlw_r_cy <- ts(df2$rstar_trend_cy, start = c(1961, 1), frequency = 4)  
us_hlw_z_cy <- ts(df2$z_trend_cy, start = c(1961, 1), frequency = 4)  
us_hlw_z <- ts(df2$z_hlw, start = c(1961, 1), frequency = 4)  
us_hlw_g <- ts(df2$g_hlw, start = c(1961, 1), frequency = 4)  
us_hlw_g_cy <- ts(df2$g_trend_cy, start = c(1961, 1), frequency = 4)  


#TS PLOT: comparing US original HLW estimates and our own.par(mfrow = c(1, 1)) 
plot(us_hlw_r_cy, type = "l", col = "lightblue4",
     xlab = "Year", ylab = "Rate",lwd=2,ylim=c(-2,6)) 
lines(us_hlw_r,col="orange3",lwd=2)
legend("topright",
       legend = c("HLW r*", "Estimated HLW r* including trend cy"),
       col = c("orange3","lightblue4"),
       lty = c(1, 1),
       lwd = c(2, 2),
       bty = "n")



#PARAMETER ESTIMATES COMPARISON
par(mfrow = c(2, 2), mar = c(2, 2, 2, 1), oma = c(3, 2, 2, 1), mgp = c(1.8, 0.6, 0))  
plot(ea_hlw_g_cy, type = "l", col = "lightblue4",
     xlab = "Year", ylab = "",lwd=2,ylim=c(1,4)) 
lines(ea_hlw_g,col="red4",lwd=2)

plot(us_hlw_g_cy, type = "l", col = "lightblue4",
     xlab = "Year", ylab = "",lwd=2,ylim=c(1,6)) 
lines(us_hlw_g,col="red4",lwd=2)

plot(ea_hlw_z_cy, type = "l", col = "lightblue4",
     xlab = "Year", ylab = "",lwd=2,ylim=c(-1.5,1)) 
lines(ea_hlw_z,col="red4",lwd=2)

plot(us_hlw_z_cy, type = "l", col = "lightblue4",
     xlab = "Year", ylab = "",lwd=2,ylim=c(-2,1)) 
lines(us_hlw_z,col="red4",lwd=2)

mtext("Euro Area", side = 3, line = 0, at = 0.27, outer = TRUE, cex = 1)
mtext("United States", side = 3, line = 0, at = 0.77, outer = TRUE, cex = 1)
mtext("g", side = 2, line = 0.05, at = 0.75, outer = TRUE, cex = 1)
mtext("z", side = 2, line = 0.05, at = 0.25,  outer = TRUE, cex = 1)
par(xpd = NA)  
legend("topright", inset = c(0.7, 1.25), legend = c("HLW model", "HLW model including cy"),
       col = c("red4","lightblue4"), lty = 1, cex = 1, bty = "n",lwd=2)

# TREND CY US
df2 <- read_excel("us_results.xlsx")
hp_result <- hpfilter(df2$cy, freq=1600)
trend_component <- hp_result$trend
ts_d5 <- ts(df2$cy, start = c(1961, 1), frequency = 4) 
ts_d6 <- ts(trend_component, start = c(1961, 1), frequency = 4)  

plot(ts_d5, type = "l", col = "grey",
     xlab = "Date", ylab = "pp",lwd=2) 
lines(ts_d6,col="lightblue4",lwd=2)
legend("bottomright",
       legend = c("Trend"),
       col = c("lightblue4"),
       lty = c(1, 1),
       lwd = c(2, 2),
       bty = "n")



## Robustness check
ts_r1 <- ts(df3$rstar, start = c(1961, 1), frequency = 4)  #Model 1
ts_r2 <- ts(df3$rstar_rob, start = c(1961, 1), frequency = 4)  #Model 2
ts_r3 <- ts(df3$rstar_rob2, start = c(1961, 1), frequency = 4) #Model 3 

plot(ts_r1, type = "l", col = "grey",
     xlab = "Year", ylab = "Natural rate",lwd=2,ylim=c(-25,8)) 
lines(ts_r2,col="lightblue4",lwd=2)
lines(ts_r3,col="yellow4",lwd=2)
legend("bottomright",
       legend = c("Model 1","Model 2","Model 3"),
       col = c("grey","lightblue4","yellow4"),
       lty = c(1, 1),
       lwd = c(2, 2),
       bty = "n")