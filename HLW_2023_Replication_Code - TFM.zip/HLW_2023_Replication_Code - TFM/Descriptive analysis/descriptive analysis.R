library(readxl)
library(readr)
library(tseries)
library(readxl)
library(psych)
library(corrplot)
library(openxlsx)


setwd('C:/Users/katti/Desktop/Máster/TFM/HLW_2023_Replication_Code - TFM/output')

# DATA

df3 <- read_excel("cointegration_data.xlsx",sheet=1)
c_data <- df3[73:139,]
vix <- c_data$vix
cds <- c_data$cds
foreign <- c_data$foreing_debt
cy_cc <- c_data$cy
debt <- c_data$treasury_securities


#DESCRIPTIVE ANALYSIS
par(mfrow = c(3, 2),mar = c(2, 4, 2, 1))
boxplot(cy_cc,main="convenience yield")
boxplot(foreign,main="% US debt held by foreign (bond demand)")
boxplot(debt,main="Treasury securities (bond supply) ")
boxplot(cds, main="JPM credit default swap")
boxplot(vix, main= "VIX")

#TS PLOTS
ts_1 <- ts(cy_cc, start = c(2008, 1), frequency = 4)  
ts_2 <- ts(foreign, start = c(2008, 1), frequency = 4)  
ts_3 <- ts(debt, start = c(2008, 1), frequency = 4)  
ts_4 <- ts(cds, start = c(2008, 1), frequency = 4)  
ts_5 <- ts(vix, start = c(2008, 1), frequency = 4)  
par(mfrow = c(3, 2),mar = c(2, 4, 2, 1))

plot(ts_1, type = "l", col = "yellow4",
     xlab = "Date", ylab = "rate",lwd=2,main="convenience yield") 
plot(ts_2, type = "l", col = "yellow4",
     xlab = "Date", ylab = "%",lwd=2,main="Foreign holding of US debt (bond demand)") 
plot(ts_3, type = "l", col = "yellow4",
     xlab = "Date", ylab = "Millions of Dollars",lwd=2,main="Treasury securities (bond supply)") 
plot(ts_4, type = "l", col = "yellow4",
     xlab = "Date", ylab = "index",lwd=2, main="JPM credit default swap (cds)") 
plot(ts_5, type = "l", col = "yellow4",
     xlab = "Date", ylab = "index",lwd=2, main= "VIX volatility index") 

#CORPLOT
data_test <- cbind(cy_cc, cds, foreign,vix,debt)
colnames(data_test) <- c("convenience yield", "credit default swap","foreign debt holding","volatility risk index","treasury securities")
par(mfrow = c(1, 1))
corr_matrix <- cor(data_test, use = "complete.obs")
custom_colors <- colorRampPalette(c("yellow4", "grey", "lightblue4"))(200)
corrplot(corr_matrix, method = "color", col=custom_colors,
         type = "upper", tl.col = "black", tl.srt = 45)



#EA NATURAL RATE DATA: time series plot
setwd('C:/Users/katti/Desktop/Máster/TFM/HLW_2023_Replication_Code - TFM')

ea.data <- read.xlsx("inputData/Holston_Laubach_Williams_current_estimates.xlsx", sheet="EA input data",
                     na.strings = ".", colNames=TRUE, rowNames=FALSE, detectDates = TRUE)
ea.log.output             <- ea.data$gdp.log
ea.inflation              <- ea.data$inflation
ea.inflation.expectations <- ea.data$inflation.expectations
ea.nominal.interest.rate  <- ea.data$interest
ea.real.interest.rate     <- ea.nominal.interest.rate - ea.inflation.expectations
ea.cy_initial             <- ea.data$us_cy
ts_1 <- ts(ea.log.output, start = c(1971, 1), frequency = 4)  
ts_2 <- ts(ea.inflation, start = c(1971, 1), frequency = 4)  
ts_3 <- ts(ea.nominal.interest.rate, start = c(1971, 1), frequency = 4)  
ts_4 <- ts(ea.real.interest.rate , start = c(1971, 1), frequency = 4)  
ts_5 <- ts(ea.cy_initial , start = c(1971, 1), frequency = 4) 
ts_6 <- ts(ea.inflation.expectations , start = c(1971, 1), frequency = 4)  

par(mfrow = c(3, 2),mar = c(2, 4, 2, 1))
plot(ts_1, type = "l", col = "yellow4",
     xlab = "Date", ylab = "rate",lwd=2,main="log output") 
plot(ts_2, type = "l", col = "yellow4",
     xlab = "Date", ylab = "%",lwd=2,main="inflation") 
plot(ts_6, type = "l", col = "yellow4",
     xlab = "Date", ylab = "rate",lwd=2, main= "inflation expectations")
plot(ts_3, type = "l", col = "yellow4",
     xlab = "Date", ylab = "%",lwd=2,main="nominal interest rate") 
plot(ts_4, type = "l", col = "yellow4",
     xlab = "Date", ylab = "index",lwd=2, main="real interest rate") 
plot(ts_5, type = "l", col = "yellow4",
     xlab = "Date", ylab = "rate",lwd=2, main= "convenience yield") 
plot(ts_6, type = "l", col = "yellow4",
     xlab = "Date", ylab = "rate",lwd=2, main= "inflation expectations") 


#US NATURAL RATE DATA: time series plot
us.data <- read.xlsx("inputData/Holston_Laubach_Williams_current_estimates.xlsx", sheet="US input data",
                     na.strings = ".", colNames=TRUE, rowNames=FALSE, detectDates = TRUE)

us.log.output             <- us.data$gdp.log
us.inflation              <- us.data$inflation
us.inflation.expectations <- us.data$inflation.expectations
us.nominal.interest.rate  <- us.data$interest
us.real.interest.rate     <- us.nominal.interest.rate - us.inflation.expectations
us.cy_initial             <- us.data$cy
us.covid.indicator        <- us.data$covid.ind

ts_1 <- ts(us.log.output, start = c(1960, 1), frequency = 4)  
ts_2 <- ts(us.inflation, start = c(1960, 1), frequency = 4)  
ts_3 <- ts(us.nominal.interest.rate, start = c(1960, 1), frequency = 4)  
ts_4 <- ts(us.real.interest.rate , start = c(1960, 1), frequency = 4)  
ts_5 <- ts(us.cy_initial , start = c(1960, 1), frequency = 4)  
ts_6 <- ts(us.inflation.expectations , start = c(1960, 1), frequency = 4)  

par(mfrow = c(3, 2),mar = c(2, 4, 2, 1))
plot(ts_1, type = "l", col = "lightblue4",
     xlab = "Date", ylab = "rate",lwd=2,main="log output") 
plot(ts_2, type = "l", col = "lightblue4",
     xlab = "Date", ylab = "%",lwd=2,main="inflation") 
plot(ts_6, type = "l", col = "lightblue4",
     xlab = "Date", ylab = "rate",lwd=2, main= "inflation expectations")
plot(ts_3, type = "l", col = "lightblue4",
     xlab = "Date", ylab = "%",lwd=2,main="nominal interest rate") 
plot(ts_4, type = "l", col = "lightblue4",
     xlab = "Date", ylab = "index",lwd=2, main="real interest rate") 
plot(ts_5, type = "l", col = "lightblue4",
     xlab = "Date", ylab = "rate",lwd=2, main= "convenience yield") 


#CY EURO AREA

df3 <- read_excel("CY.xlsx",sheet = 1)
spain <- ts(df3$spain_cy, start = c(1997, 1), frequency = 4)  # Adjust the frequency depending on your data
germany <- ts(df3$germany_cy, start = c(1997, 1), frequency = 4)  # Adjust the frequency depending on your data
france <- ts(df3$france_cy, start = c(1997, 1), frequency = 4)  # Adjust the frequency depending on your data
portugal <- ts(df3$portugal_cy, start = c(1997, 1), frequency = 4)  # Adjust the frequency depending on your data
eu <- ts(df3$eu_cy, start = c(1997, 1), frequency = 4)  # Adjust the frequency depending on your data
italy <- ts(df3$italy_cy, start = c(1997, 1), frequency = 4)  # Adjust the frequency depending on your data

plot(spain, type = "l", col = "lightblue",
     xlab = "Date", ylab = "pp",lwd=2,ylim=c(-4,2.5)) 
lines(germany,col="orange3",lwd=2)
lines(france,col="pink2",lwd=2)
lines(italy,col="grey",lwd=2)
lines(eu,col="green4",lwd=2)

legend("bottomright",
       legend = c("Spain","Germany","France","Italy","EU Average"),
       col = c("lightblue", "orange3","pink2","grey","green4"),
       lty = c(1, 1),
       lwd = c(2, 2),
       bty = "n")


#CY US

#TS US-GERMANY
plot(germany, type = "l", col = "grey",
     xlab = "Date", ylab = "pp",lwd=2,xlim = c(1960, 2024)) 
lines(ts_5,col="lightblue4",lwd=2)
legend("bottomright",
       legend = c("Germany","US"),
       col = c("grey","lightblue4"),
       lty = c(1, 1),
       lwd = c(2, 2),
       bty = "n")


