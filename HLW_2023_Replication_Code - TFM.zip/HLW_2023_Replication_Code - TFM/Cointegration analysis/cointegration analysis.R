install.packages(c("urca", "tsDyn", "vars", "tseries"))
library(urca)
library(tsDyn)
library(vars)
library(tseries)
library(readxl)
library(psych)
library(corrplot)
library(lmtest)
library(sandwich)
library(urca)


setwd('C:/Users/katti/Desktop/Máster/TFM/HLW_2023_Replication_Code - TFM/output')

# DATA

df3 <- read_excel("cointegration_data.xlsx",sheet=1)
c_data <- df3[73:139,]
vix <- log(c_data$vix)
cds <- log(c_data$cds)
foreign <- log(c_data$foreing_debt)
cy_cc <- log(c_data$cy)
debt <- log(c_data$treasury_securities)

#STATIONARITY
#LEVELS
adf.test(cy_cc)
adf.test(cds)
adf.test(vix)
adf.test(foreign)
adf.test(debt)

#FIRST DIFFERENCES
adf.test(diff(cy_cc))
adf.test(diff(cds))
adf.test(diff(vix))
adf.test(diff(foreign))
adf.test(diff(debt))

#ANALYSIS COINT
cy_cc <- ts(cy_cc, start = c(2008, 1), frequency = 4)  
foreign <- ts(foreign, start = c(2008, 1), frequency = 4)  
cds <- ts(cds, start = c(2008, 1), frequency = 4)  
vix <- ts(vix, start = c(2008, 1), frequency = 4)  
debt <- ts(debt, start = c(2008, 1), frequency = 4)  
data_test <- cbind(cy_cc, cds, foreign,vix,debt)
colnames(data_test) <- c("cy", "cds","demand","vix","supply")

#Estimate the long-run equation and get residuals
long_run <- lm(cy_cc ~ foreign*vix + vix  + cds + debt)
summary(long_run)


# Residuals analysis
residuals_longrun <- residuals(long_run)
bptest(long_run)
shapiro.test(residuals(long_run))
adf.test(residuals(long_run))
par(mfrow = c(1, 1))
qqnorm(residuals(long_run))
qqline(residuals(long_run), col = "red")

# Estimate the ECM
ecm_data <- data.frame(
  d_cy_cc     = diff(cy_cc),
  d_foreign   = diff(foreign),
  d_vix       = diff(vix),
  d_cds       = diff(cds),
  d_supply    = diff(debt),
  d_interact  = diff(foreign * vix),
  u_lag       = head(residuals_longrun, -1)
)

ecm_model <- lm(d_cy_cc ~ d_foreign + d_vix +d_supply + d_cds  + d_interact + u_lag, data = ecm_data)
summary(ecm_model)
bgtest(ecm_model, order = 1) 
bptest(ecm_model)
shapiro.test(residuals(ecm_model))
adf.test(residuals(ecm_model))
par(mfrow = c(1, 1))

qqnorm(residuals(ecm_model))
qqline(residuals(ecm_model), col = "red")

